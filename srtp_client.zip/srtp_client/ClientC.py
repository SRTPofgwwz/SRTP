import io
import json
import os
import socket
import struct
import threading
import tkinter.filedialog
from tkinter import *

import gnupg

import decrypt


class Client():
    def __init__(self,init_window_name,ip_inaddress,in_port,ip_outaddress,out_port):
        self.init_window_name = init_window_name
        self.ip_inaddress = ip_inaddress
        self.in_port = in_port
        self.ip_outaddress = ip_outaddress
        self.out_port = out_port
        print(self.ip_inaddress,self.ip_outaddress,self.in_port,self.out_port)
    #设置窗口
    def set_init_window(self):
        self.init_window_name.title("聊天工具客户端")           #窗口名
        self.init_window_name.geometry('500x681')
        #self.init_window_name.attributes("-alpha",0.9)                          #虚化，值越小虚化程度越高
        #标签
        self.result_data_label = Label(self.init_window_name, text="接收到的消息")
        self.result_data_label.grid(row=1, column=0)
        self.log_label = Label(self.init_window_name, text="传输日志")
        self.log_label.grid(row=12, column=0)
        #文本框
        self.result_data_Text = Text(self.init_window_name, width=67, height=35)  #原始数据录入框
        self.result_data_Text.grid(row=2, column=0, rowspan=10, columnspan=10)
        self.log_data_Text = Text(self.init_window_name, width=66, height=9)  # 日志框
        self.log_data_Text.grid(row=13, column=0, columnspan=10)
        
        #按钮
        self.sendfile_button = Button(self.init_window_name, text="传输文件", bg="lightblue", width=15,command = self.sendfile)  # 调用内部方法  加()为直接调用
        self.sendfile_button.grid(row=0, column=0)
        '''
        thread_receive = threading.Thread(target = self.receive,args=(self,))
        logmsg = 'create server success\n'
        self.log_data_Text.insert(END, logmsg)
        thread_receive.start()
        '''

    def sendfile(self):
        filepath = tkinter.filedialog.askopenfilename()
        gpg = gnupg.GPG()
        keyfile_name = 'mykeyfile.asc' # path + keyfile
        with open(keyfile_name) as f:
            key_data = f.read()
        import_result = gpg.import_keys(key_data)

        #filepath="A" #input("please input the path of the file: ") #得到原文件的路径

        try:
        #create an AF_INET, STREAM socket (TCP)
          sendsock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        except(socket.error ,msg):
            logmsg = 'Failed to create socket. Error code: ' + str(msg[0]) + ' , Error message : ' + msg[1] + '\n\n'
            self.log_data_Text.insert(END, logmsg)
            os._exit()
        #sendsock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)#创建TCP连接 AF_INET服务器之间网络通信
        #SOCK_STREAM-TCP
        #sendsock.connect(("127.0.0.1",3008))#连接到给定套接字
        sendsock.connect((self.ip_outaddress,self.out_port))

        logmsg = "connect success....\n"
        self.log_data_Text.insert(END, logmsg)

        stream = open(filepath, 'rb')
        g = gpg.encrypt_file(stream, recipients=['me@email.com'])
        print(str(g))
        fl = bytes(str(g), 'ascii')
        #img = open('encrypted',"rb") #二进制打开文件用于读写

        #size =  os.stat(filepath).st_size #得到文件的大小，以位(bit)为单位
        size=len(fl)
        f= struct.pack("l",size) #将C中long类型的数据打包成python中intenger类型
        sendsock.send(f) #发送TCP数据，将f中的数据发送到连接的套接字，返回要发送的字节数量


        if g.ok==True:
            sendsock.sendall(fl) #完整发送TCP数据，将原文件中读取的数据发送到连接的套接字
        else:
           logmsg = 'failed to encrypt the file\n'
           self.log_data_Text.insert(END, logmsg)

        #img.close() #关闭文件
        sendsock.close() #关闭套接字
    
    def receive(self):
        receivesock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  # 建立TCP连接
        receivesock.bind((self.ip_inaddress, self.in_port))  # 将套接字绑定到地址
        receivesock.listen(3)  # 可建立socket连接的排队的个数，Linux为无限大
        count = 1

        self.result_data_Text.delete(1.0,END)

        while True:
            logmsg = "start.......\n"
            self.result_data_Text.insert(END, logmsg)

            """
            调用accept()方法时，socket会进入"waiting"状态。客户请求连接时，方法
            建立连接并返回服务器.accept()方法返回一个含有两个元素的元组。第一个元素
            是新的socket对象，服务器通过该socket对象与客户通信；第二个元素是客户的
            internet地址
            """
            sock, adddr = receivesock.accept()

            """
            recv()方法从客户端接收信息，最后返回一个字符串来表示收到的数据。调用
            一个整数来控制本次调用所接受的最大数据量。
            """
            #calcsize()方法计算给定的格式（intenger）占用的字节数
            data_size = sock.recv(4)

            # 按格式（intenger）解析接收到的字符串
            total_size = struct.unpack("i", data_size)[0]
            outfile_name = "copy" + str(count)

            logmsg = outfile_name
            self.result_data_Text.insert(END, logmsg)

            outfile=open(outfile_name,"wb")
            if_break = 2 # 没有可读取字符时关闭文件
            data = sock.recv(4) # 前4字节不读取 # ？不明原因，可能和一开始发送的字符数变量有关 —— Bruce
            while total_size>0:
                readlen=1024
                if total_size<readlen:
                    readlen=total_size

                data=sock.recv(readlen)
                outfile.write(data)            
                total_size-=len(data)
                if len(data) == 0: # 检查是否还有字节发送过来
                    if_break -= 1
            
                if if_break == 0:
                    break # 没有可读取字符时关闭文件

            outfile.close()
            decryptfilename = "decrypted" + str(count)       #解密后的文件名
            decrypt.decryptor(outfile_name, "mykeyfile.asc", decryptfilename) # 解密文件

            logfile = open(decryptfilename, 'r')
            logmsg = logfile.read()
            self.result_data_Text.insert(END, "\n文件内容: \n" + logmsg)
            logfile.close()

            count = count + 1
            print(count)
