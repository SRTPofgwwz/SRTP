import socket
import threading
import tkinter.filedialog
import os
from tkinter import *

import ClientC

'''
def main():
    
    sendfile_button = Button("聊天程序客户端", text="传输文件", bg="lightblue", width=15,command = lambda:tcp_send.sendfile(filepath ,ip_outaddress ,out_port))  # 调用内部方法  加()为直接调用
    sendfile_button.grid(row=0, column=0)
    
    #设置接收函数相关参数
    ip_inaddress = '0.0.0.0'
    in_port = 8888

    #设置发送函数相关参数
    
    ip_outaddress = 0
    while(ip_outaddress == 0):
        ip_outaddress = input("输入ip")
    ip_outaddress = Entry(window)
    ip_outaddress.insert(0,"请输入IP地址")   #插入序号为0，后为字符串
    
    filepath = tkinter.filedialog.askopenfilename()
    ip_outaddress = '192.168.110.129'
    out_port = 8888
    #thread_receive = threading.Thread(target = tcp_recieve.receive, args=(ip_inaddress, in_port))
    #thread_send = threading.Thread(target = tcp_send.fsend, args=(filepath ,ip_outaddress ,out_port))
    thread_receive.start()
    #thread_send.start()
    thread_receive.join()
    #thread_send.join()
'''
def gui_start():
    ip_inaddress = '0.0.0.0'
    in_port = 8888
    #ip_outaddress = '192.168.110.128'
    ip_outaddress = '127.0.0.1'
    out_port = 8888
    init_window = Tk()              #实例化出一个父窗口
    myClient = ClientC.Client(init_window,ip_inaddress,in_port,ip_outaddress,out_port)
    # 设置根窗口默认属性
    myClient.set_init_window()
    
    thread_receive = threading.Thread(target = myClient.receive)
    logmsg = 'create server success\n'
    myClient.log_data_Text.insert(END, logmsg)
    thread_receive.start()
    print(os.getpid())
    init_window.mainloop()          #父窗口进入事件循环，可以理解为保持窗口运行，否则界面不展示   


if __name__ == "__main__":
    gui_start()
